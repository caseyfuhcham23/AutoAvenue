<?php
session_start();
include 'dbconfig.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE Email='$email' AND PasswordHash='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION["user_id"] = $row["UserID"];
        header("Location: search.php");
    } else {
        echo "Invalid login credentials. <a href='index.php'>Try Again</a>";
    }

    $conn->close();
}
?>

