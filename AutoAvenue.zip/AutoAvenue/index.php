<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - AutoAvenue</title>
    <style>
        body { background-color: grey; color: black; }
        form { margin: 20% auto; width: 300px; }
        input { width: 100%; margin-bottom: 10px; }
        button { width: 100%; }
    </style>
</head>
<body>
    <form action="login.php" method="post">
        <h2>Login to AutoAvenue</h2>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>
