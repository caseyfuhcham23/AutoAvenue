<?php
$host="127.0.0.1";
$user="root";
$pass="";
$dbname="autoavenue_db";
$conn=mysqli_connect($host, $user, $pass, $dbname);